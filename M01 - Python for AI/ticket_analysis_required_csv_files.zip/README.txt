Ticket Analysis Lab - CSV files

tickets.csv: 10 valid sample records for the main Pandas analysis.
tickets_with_invalid_records.csv: 10 valid records plus 5 intentionally invalid records for practising Pydantic validation.

Columns: ticket_id, customer_name, category, priority, status, resolution_hours
